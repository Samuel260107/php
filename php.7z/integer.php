<?php
$num = 3;
if(is_integer($num)){
    echo "Número inteiro";
}else{
    echo "O valor da variável não é um número inteiro!";
}
?>