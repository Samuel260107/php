<?php
$num = 25.28;
if(is_object($num)){
    echo "Tipo OBJECT";
}else{
    echo "Não é um OBJECT";
}
?>