<?php
$num = 25.28;
if(is_string($num)){
    echo "String";
}else{
    echo "Não é um STRING";
}
?>