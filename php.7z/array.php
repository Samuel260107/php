<?php
$num = 25.28;
if(is_array($num)){
    echo "Tipo ARRAY";
}else{
    echo "Não é um ARRAY";
}
?>