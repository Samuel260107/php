<?php
$num = 3.8;
if(is_int($num)){
    echo "Número inteiro";
}else{
    echo "O valor da variável não é um número inteiro!";
}
?>