<?php
$num = 28;
if(is_real($num)){
    echo "Número Real";
}else{
    echo "O valor da variável não é um número REAL";
}
?>