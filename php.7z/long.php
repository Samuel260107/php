<?php
$num = 25.28;
if(is_long($num)){
    echo "Número inteiro";
}else{
    echo "Não é um número inteiro";
}
?>