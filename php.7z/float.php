<?php
$num = 25.28;
if(is_float($num)){
    echo "Número REAL";
}else{
    echo "Não é um número REAL";
}
?>